// components/Dashboard/Sidebar.jsx
import React, { useEffect } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import {
  LayoutDashboard,
  Activity,
  Grid3X3,
  Sparkles,
  ArrowLeft,
  LogOut, // Added LogOut icon for semantic clarity
  Info, // Added Info icon for "How Credits Work"
} from "lucide-react";

/**
 * Controlled Sidebar component.
 * Props:
 * - activeTab, setActiveTab
 * - setIsModalOpen
 * - buttonVariants (optional)
 * - isSidebarExpanded (boolean), setIsSidebarExpanded (fn)
 *
 * This component DOES NOT read localStorage itself — Dashboard provides the state
 * (so there is only one source of truth and no race/hydration issues).
 */
const EXPANDED_PX = 240; // 16rem
const COLLAPSED_PX = 64; // 4rem

// Define static data structures outside the component to prevent re-creation on every render.
const NAV_ITEMS = [
  { name: "Dashboard", icon: LayoutDashboard, tab: "dashboard" },
  { name: "Activity", icon: Activity, tab: "activity" },
  { name: "Templates", icon: Grid3X3, tab: "templates" },
];

const RESOURCE_ITEMS = [
  // "How Credits Work" is likely informational, so it's a link.
  { name: "How Credits Work", icon: Info, type: "link", href: "#" },
  // "Generate with AI" likely triggers an action (e.g., modal), so it's a button.
  { name: "Generate with AI", icon: Sparkles, type: "button" },
];

/**
 * Helper component for sidebar items to reduce repetition and improve readability/maintainability.
 * This component encapsulates the common rendering logic for navigation and resource items,
 * including accessible tooltips.
 */
function SidebarItem({
  icon: Icon,
  name,
  isActive,
  isExpanded,
  onClick,
  isLink = false,
  href,
  ariaLabel,
  className = "", // Allows passing additional Tailwind classes
}) {
  const commonClasses = `group relative flex items-center w-full py-3 rounded-lg transition-colors`;
  const expandedClasses = `justify-start px-4`;
  const collapsedClasses = `justify-center px-0`;
  const activeClasses = `bg-purple-600 text-white`;
  const inactiveClasses = `text-gray-300 hover:bg-gray-800 hover:text-white`;

  // Dynamically choose between 'a' (link) or 'button' based on `isLink` prop for semantic correctness.
  const Element = isLink ? "a" : "button";
  const tooltipId = `${name.toLowerCase().replace(/\s/g, "-")}-tooltip`;

  return (
    <Element
      onClick={onClick}
      href={href} // 'href' is only relevant for 'a' elements
      aria-current={isActive ? "page" : undefined} // Indicates the current page in a set of links
      aria-label={ariaLabel || (isExpanded ? undefined : name)}
      aria-describedby={!isExpanded ? tooltipId : undefined}
      className={`${commonClasses} ${
        isExpanded ? expandedClasses : collapsedClasses
      } ${isActive ? activeClasses : inactiveClasses} ${className}`}
      title={isExpanded ? undefined : name}
    >
      <Icon size={18} />
      {isExpanded && <span className="ml-3 whitespace-nowrap">{name}</span>}
      {!isExpanded && (
        // Accessible tooltip for collapsed state.
        <span
          id={tooltipId}
          role="tooltip" // Explicitly defines this as a tooltip for assistive technologies
          className="absolute left-full ml-2 px-2 py-1 rounded bg-gray-800 text-white text-xs opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 whitespace-nowrap pointer-events-none"
        >
          {name}
        </span>
      )}
    </Element>
  );
}

export default function Sidebar({
  activeTab,
  setActiveTab,
  setIsModalOpen, // This prop is not used in the provided code, but kept for signature consistency.
  buttonVariants, // This prop is not used in the provided code, but kept for signature consistency.
  isSidebarExpanded,
  setIsSidebarExpanded,
}) {
  // Update the CSS variable for sidebar width on the document's root element.
  useEffect(() => {
    const width = isSidebarExpanded ? EXPANDED_PX : COLLAPSED_PX;
    document.documentElement.style.setProperty("--sidebar-width", `${width}px`);
  }, [isSidebarExpanded]); // Dependency array ensures effect runs only when isSidebarExpanded changes.

  // Framer Motion animation style for the sidebar width.
  const animateStyle = {
    width: isSidebarExpanded ? EXPANDED_PX : COLLAPSED_PX,
  };

  return (
    <>
      <motion.aside
        initial={false} // Prevents initial animation on mount
        animate={animateStyle}
        transition={{ duration: 0.39, ease: "easeInOut" }} // Concise duration for snappy feel
        aria-expanded={isSidebarExpanded} // Conveys expanded/collapsed state to assistive technologies
        className="fixed left-0 top-0 h-screen bg-[#0b1221] text-white flex flex-col overflow-hidden"
        style={{ minWidth: COLLAPSED_PX }}
      >
        {/* Header */}
        <div
          className={`flex items-center h-16 border-b border-gray-800 ${
            isSidebarExpanded ? "justify-between px-4" : "justify-center px-2"
          }`}
        >
          <div>
            {isSidebarExpanded && (
              <span className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center shadow">
                  <Sparkles className="text-white" />
                </div>
                <div className="text-lg font-semibold whitespace-nowrap">
                  Skill Tracker
                </div>
              </span>
            )}
          </div>

          {/* Toggle button - always visible */}
          <button
            onClick={() => setIsSidebarExpanded((s) => !s)}
            aria-label={
              isSidebarExpanded ? "Collapse sidebar" : "Expand sidebar"
            }
            className="p-2 rounded-full text-gray-300 hover:text-white hover:bg-gray-800 focus:outline-none"
            style={{
              ...(isSidebarExpanded
                ? {}
                : { position: "absolute", right: 6, top: 8 }),
            }}
          >
            {/* Using a custom SVG for the toggle icon */}
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
            >
              <path
                d="M3 6h18M3 12h18M3 18h18"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
        </div>

        {/* Navigation Section */}
        <div className="flex flex-col flex-1 mt-4 px-1">
          {/* Back to Home button, using SidebarItem for consistency */}
          <SidebarItem
            icon={ArrowLeft}
            name="Back to Home"
            // Import Link at the top: import { Link } from "react-router-dom"
            as={Link}
            to="/homepage"
            isExpanded={isSidebarExpanded}
            ariaLabel="Back to Dashboard Home" // More specific aria-label
          />

          {/* Main navigation, using <nav> for semantic correctness */}
          <nav
            className="flex flex-col gap-2 mt-1 px-1"
            aria-label="Main Navigation"
          >
            {NAV_ITEMS.map((item) => (
              <SidebarItem
                key={item.tab}
                icon={item.icon}
                name={item.name}
                isActive={activeTab === item.tab}
                isExpanded={isSidebarExpanded}
                onClick={() => setActiveTab(item.tab)}
              />
            ))}
          </nav>

          {/* Resources Section */}
          <div
            className={`mt-6 ${
              isSidebarExpanded ? "" : "flex flex-col items-center gap-3"
            }`}
          >
            {isSidebarExpanded && (
              <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-widest px-4 mb-2">
                Resources
              </h4>
            )}

            {/* Resource links/buttons, using <nav> if they function as navigation */}
            <nav
              className={`${
                isSidebarExpanded
                  ? "flex flex-col gap-2 px-1"
                  : "flex flex-col gap-3"
              }`}
              aria-label="Resource Links" // Added aria-label for semantic navigation
            >
              {RESOURCE_ITEMS.map((item, i) => (
                <SidebarItem
                  key={i}
                  icon={item.icon}
                  name={item.name}
                  // Conditional onClick for button type, otherwise undefined for links
                  onClick={
                    item.type === "button"
                      ? () => console.log(`${item.name} clicked`)
                      : undefined
                  }
                  isExpanded={isSidebarExpanded}
                  isLink={item.type === "link"} // Pass type to SidebarItem to render 'a' or 'button'
                  href={item.href} // Pass href for link type
                />
              ))}
            </nav>
          </div>
        </div>
        {/* Footer */}
        <div className="px-2 py-4 border-t border-gray-800">
          {/* Logout button, using SidebarItem and LogOut icon for semantic clarity */}
          <SidebarItem
            icon={LogOut}
            name="Logout"
            onClick={() => {
              /* implement logout */
              console.log("Logout clicked");
            }}
            isExpanded={isSidebarExpanded}
            // Custom styling for logout button, demonstrating `className` prop usage
            className="hover:bg-red-600/10 hover:text-red-400"
          />
        </div>
      </motion.aside>
    </>
  );
}
