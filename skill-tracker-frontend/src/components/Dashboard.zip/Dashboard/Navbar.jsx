// src/components/Dashboard/Navbar.jsx
import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  LayoutDashboard,
  Activity,
  Grid3X3,
  Sparkles,
  Menu,
  X,
  User,
  Settings,
} from "lucide-react";

/**
 * Navbar - top navigation intended for mobile / small screens.
 * It's fixed at the top and adds spacing for page content.
 */
const NAV_ITEMS = [
  { name: "Dashboard", icon: LayoutDashboard, path: "/dashboard" },
  { name: "Activity", icon: Activity, path: "/activity" },
  { name: "Templates", icon: Grid3X3, path: "/templates" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-[#0b1221] text-white shadow">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="h-14 flex items-center justify-between">
          <Link to="/home" className="flex items-center gap-3 text-white">
            <div className="w-8 h-8 bg-purple-500 rounded-lg flex items-center justify-center">
              <Sparkles size={16} className="text-white" />
            </div>
            <div className="text-sm font-semibold whitespace-nowrap">
              Skill Tracker
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-2">
            {NAV_ITEMS.map((n) => (
              <Link
                key={n.name}
                to={n.path}
                className="flex items-center gap-2 px-3 py-2 rounded hover:bg-gray-800 text-gray-300"
              >
                <n.icon size={16} />
                <span className="text-sm">{n.name}</span>
              </Link>
            ))}
            <Link
              to="/profile"
              className="px-3 py-2 rounded hover:bg-gray-800 text-gray-300"
            >
              <User size={16} />
            </Link>
            <Link
              to="/settings"
              className="px-3 py-2 rounded hover:bg-gray-800 text-gray-300"
            >
              <Settings size={16} />
            </Link>
          </nav>

          <div className="md:hidden">
            <button
              onClick={() => setOpen((s) => !s)}
              aria-label="Toggle navigation"
              className="p-2 rounded hover:bg-gray-800 text-gray-300"
            >
              {open ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden bg-[#071021] border-t border-gray-800">
          <div className="px-3 py-2 space-y-1">
            {NAV_ITEMS.map((n) => (
              <Link
                key={n.name}
                to={n.path}
                onClick={() => setOpen(false)}
                className="flex items-center gap-3 px-3 py-2 rounded hover:bg-gray-800 text-gray-300"
              >
                <n.icon size={16} />
                <span>{n.name}</span>
              </Link>
            ))}
            <Link
              to="/profile"
              onClick={() => setOpen(false)}
              className="flex items-center gap-3 px-3 py-2 rounded hover:bg-gray-800 text-gray-300"
            >
              <User size={16} />
              <span>Profile</span>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
